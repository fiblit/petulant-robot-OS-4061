#include <errno.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>

pid_t r_wait ( int *stat_loc );
